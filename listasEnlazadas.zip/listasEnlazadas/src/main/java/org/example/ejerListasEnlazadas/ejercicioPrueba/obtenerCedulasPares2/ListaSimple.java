package org.example.ejerListasEnlazadas.ejercicioPrueba.obtenerCedulasPares2;


import java.util.ArrayList;
import java.util.List;

public class ListaSimple {
    Nodo nodoPrimero ;
    int tamano;

    public void ListaSimple(){
        nodoPrimero=null;
        tamano=0;
    }


    public void agregarNodo(Persona valor) {
       Nodo nuevoNodo = new Nodo(valor);
        if (nodoPrimero == null) {
            // Si la lista está vacía, el nuevo nodo se convierte en el primer nodo
            nodoPrimero = nuevoNodo;
        } else {
            // Si la lista no está vacía, se busca el último nodo y se le asigna el nuevo nodo
            Nodo ultimoNodo = obtenerUltimoNodo();
            ultimoNodo.siguienteNodo = nuevoNodo;
        }

        tamano++;
    }

    // Método para obtener el último nodo en la lista
    private Nodo obtenerUltimoNodo() {
       Nodo actual = nodoPrimero;
        while (actual.siguienteNodo != null) {
            actual = actual.siguienteNodo;
        }
        return actual;
    }


    public List<Persona> obtenerCedulasPares(){
        List listaPersona=new ArrayList<>();
        Nodo actualNodo= nodoPrimero;
        while (actualNodo!=null){
            if((actualNodo.valor.cedula).length()%2==0) {
                listaPersona.add(actualNodo.valor);
            }
            actualNodo = actualNodo.siguienteNodo;
        }
        return listaPersona;

    }
}
