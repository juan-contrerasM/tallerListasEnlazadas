package org.example.ejerListasEnlazadas.ejerciciosOriginalesSimple.ObtenercedulaPar2;

public class ObtenerCedulasPares {
    public static void main(String[] args) {
        //se crean listas
        ListaSimple<Persona> personas= new ListaSimple<>();


        // se agregan personas
        Persona p1= new Persona("juan","1");
        Persona p2= new Persona("jose","12");
        Persona p3=new Persona("contreras","123");
        Persona p4= new Persona("molina", "1234");

        personas.agregarfinal(p1);
        personas.agregarfinal(p2);
        personas.agregarfinal(p3);
        personas.agregarfinal(p4);





        //identidicar posiciones impares
        for (int i = 0; i < personas.getTamanio() ; i++) {
            if(personas.obtenerValorNodo(i).getCedula().length()%2==0){
                System.out.println(personas.obtenerValorNodo(i).getNombre());
            }
        }


    }
}
