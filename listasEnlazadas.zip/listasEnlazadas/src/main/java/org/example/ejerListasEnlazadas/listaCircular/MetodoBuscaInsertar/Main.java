package org.example.ejerListasEnlazadas.listaCircular.MetodoBuscaInsertar;

public class Main {
    public static void main(String[] args) {
        ListaSimpleCircular<Integer> numeros = new ListaSimpleCircular<>();

        numeros.agregarfinal(1);
        numeros.agregarfinal(2);
        numeros.agregarfinal(3);
        numeros.agregarInicio(5);

        System.out.println(numeros.obtenerValorNodo(1));
    }

}
