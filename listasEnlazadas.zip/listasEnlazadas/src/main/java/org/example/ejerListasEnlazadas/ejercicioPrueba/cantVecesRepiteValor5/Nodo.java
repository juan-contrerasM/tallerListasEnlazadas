package org.example.ejerListasEnlazadas.ejercicioPrueba.cantVecesRepiteValor5;

public class Nodo {
    Nodo siguienteNodo;
    int valor;
    public Nodo(int valor){
        siguienteNodo=null;
        this.valor=valor;
    }
}
