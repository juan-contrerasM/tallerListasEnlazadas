package org.example.ejerListasEnlazadas.preparcial;

import java.util.HashMap;

public class Main {
    public static void main(String[] args) {



                // Crear un nuevo HashMap
                HashMap<String, String> s = new HashMap<>();

                // Agregar pares clave-valor al mapa
                s.put("i", null);
                s.put("k", "JavaSE");
                s.put("j", "PHP");
                s.put("m", "Python");
                s.put(null, "JAVA");
                s.put(null, null);

                // Imprimir el tamaño del mapa
                System.out.println("Tamaño del mapa: " + s.size());

                // Imprimir el contenido del mapa
                for (String clave : s.keySet()) {
                    String valor = s.get(clave);
                    System.out.println("Clave: " + clave + ", Valor: " + valor);
                }
            }



}
