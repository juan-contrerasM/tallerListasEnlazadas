package org.example.ejerListasEnlazadas.ejercicioPrueba.eliminarNumeroPares3;

public class Nodo {
    Nodo siguinteNodo;
    int valor;

    public Nodo(int  valor){
        siguinteNodo=null;
        this.valor=valor;
    }
}
