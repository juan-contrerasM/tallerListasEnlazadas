package org.example.ejerListasEnlazadas.ejercicioPrueba.cantVecesRepiteValor5;


public class ListaSimple {
    Nodo nodoPrimero;
    int tamano;
    int puntero;

    // Constructor de la clase ListaSimple
    public ListaSimple() {
        nodoPrimero = null;
        tamano = 0;
    }


    public void agregarNodo(int valor) {
        Nodo nuevoNodo = new Nodo(valor);

        if (nodoPrimero == null) {
            // Si la lista está vacía, el nuevo nodo se convierte en el primer nodo
            nodoPrimero = nuevoNodo;
        } else {
            // Si la lista no está vacía, se busca el último nodo y se le asigna el nuevo nodo
            Nodo ultimoNodo = obtenerUltimoNodo();
            ultimoNodo.siguienteNodo = nuevoNodo;
        }

        tamano++;
    }

    // Método para obtener el último nodo en la lista
    private Nodo obtenerUltimoNodo() {
      Nodo actual = nodoPrimero;
        while (actual.siguienteNodo != null) {
            actual = actual.siguienteNodo;
        }
        return actual;
    }

    // Método para recorrer e imprimir los elementos de la lista
    public int recorrer(int valor){
        Nodo actual= nodoPrimero;
        while (actual!=null){
            if(actual.valor==valor){
                puntero++;
            }
            actual=actual.siguienteNodo;

        }
        return puntero;
    }

}