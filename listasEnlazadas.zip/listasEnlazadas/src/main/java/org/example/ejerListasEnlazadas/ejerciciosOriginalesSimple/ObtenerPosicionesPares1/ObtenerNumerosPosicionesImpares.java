package org.example.ejerListasEnlazadas.ejerciciosOriginalesSimple.ObtenerPosicionesPares1;

import java.util.ArrayList;

public class ObtenerNumerosPosicionesImpares {
    public static void main(String[] args) {
        //se crean listas
        ListaSimple<Integer>numeros= new ListaSimple<>();
        ArrayList<Integer>numerosObtenidos=new ArrayList<>();

        // se agregan numeros
        numeros.agregarfinal(1);
        numeros.agregarfinal(2);
        numeros.agregarfinal(3);
        numeros.agregarfinal(4);
        numeros.agregarfinal(5);

        //identidicar posiciones impares
        for (int i = 0; i < numeros.getTamanio() ; i++) {
            if(i%2!=0){
                numerosObtenidos.add(numeros.obtenerValorNodo(i));
            }
        }

        //imprimir
        for (int i = 0; i <numerosObtenidos.size() ; i++) {
            System.out.println(numerosObtenidos.get(i));
        }
    }
}
