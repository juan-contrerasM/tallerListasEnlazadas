package org.example.ejerListasEnlazadas.ejerciciosDoblementeEnlazada.cedulasPares;

import org.example.ejerListasEnlazadas.ejercicioPrueba.obtenerCedulasPares2.ListaSimple;
import org.example.ejerListasEnlazadas.ejercicioPrueba.obtenerCedulasPares2.Persona;

public class Main {
    public static void main(String[] args) {
        ListaDoble<Persona> lista = new ListaDoble<>();
        Persona p1 = new Persona("1", "Juan");
        Persona p2 = new Persona("12", "Jose");
        Persona p3 = new Persona("133", "contreras");
        Persona p4 = new Persona("1444", "molina");
        lista.agregarInicio(p1);
        lista.agregarInicio(p2);
        lista.agregarInicio(p3);
        lista.agregarInicio(p4);

        for (int i = 0; i <lista.getTamanio() ; i++) {
            if(lista.obtenerValorNodo(i).getCedula().length()%2==0){
                System.out.println(lista.obtenerValorNodo(i).getNombre());
            }
        }
    }
}
