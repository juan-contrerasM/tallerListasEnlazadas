package org.example.ejerListasEnlazadas.Parcial.punto2;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Object>lista1= new ArrayList<>();
        lista1.add(1);
        lista1.add(2);
        lista1.add(3);

        List<Object>lista2= new ArrayList<>();
        lista2.add(1);
        lista2.add(2);
        lista2.add(4);
        Set<Object>union=concatenarListas(lista1,lista2);

        for (Object object:union) {
            System.out.println(object);
        }


    }
    public static Set<Object> concatenarListas(List<Object>lista1,List<Object>list2){
        Set<Object>union= new HashSet<>();
        for (int i = 0; i <lista1.size() ; i++) {
            union.add(lista1.get(i));
        }
        for (int i = 0; i < list2.size(); i++) {
            union.add(list2.get(i));

        }
        return union;

    }
}
