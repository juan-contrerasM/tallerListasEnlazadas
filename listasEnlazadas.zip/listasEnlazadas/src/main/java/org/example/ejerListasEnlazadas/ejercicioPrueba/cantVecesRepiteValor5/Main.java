package org.example.ejerListasEnlazadas.ejercicioPrueba.cantVecesRepiteValor5;



public class Main {
    public static void main(String[] args) {

      ListaSimple lista = new ListaSimple();
        lista.agregarNodo(1);
        lista.agregarNodo(2);
        lista.agregarNodo(3);
        lista.agregarNodo(3);
        lista.agregarNodo(3);

        System.out.println("Elementos de posiciones impares de la lista:");
        System.out.println(lista.recorrer(1));




        }
    }
