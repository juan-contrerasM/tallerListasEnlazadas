package org.example.ejerListasEnlazadas.Parcial.punto3;

public class Empresa {
    Bodega <NodoDoble> bodega = new Bodega<>();


}
