package org.example.ejerListasEnlazadas.ejercicioPrueba.obtenerNumerosImpares1;

public class Main {
    public static void main(String[] args) {
            // Ejemplo de uso
        ListaSimple lista = new ListaSimple();
        lista.agregarNodo(1);
        lista.agregarNodo(2);
        lista.agregarNodo(3);

        System.out.println("Elementos de posiciones impares de la lista:");
        lista.obtenerNumerosImpares();



        }
    }
