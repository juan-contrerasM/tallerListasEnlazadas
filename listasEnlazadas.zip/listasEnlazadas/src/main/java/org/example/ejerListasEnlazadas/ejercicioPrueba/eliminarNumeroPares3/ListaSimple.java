package org.example.ejerListasEnlazadas.ejercicioPrueba.eliminarNumeroPares3;

public class ListaSimple {
    Nodo primerNodo;
    int tamano=0;
    int puntero=0;

    public ListaSimple(){
        primerNodo=null;
        tamano=0;
    }
    public void agregarNodo(int valor) {
       Nodo nuevoNodo = new Nodo(valor);
        if (primerNodo == null) {
            // Si la lista está vacía, el nuevo nodo se convierte en el primer nodo
            primerNodo = nuevoNodo;
        } else {
            // Si la lista no está vacía, se busca el último nodo y se le asigna el nuevo nodo
           Nodo ultimoNodo = obtenerUltimoNodo();
            ultimoNodo.siguinteNodo = nuevoNodo;
        }

        tamano++;
    }

    // Método para obtener el último nodo en la lista
    private Nodo obtenerUltimoNodo() {
        Nodo actual = primerNodo;
        while (actual.siguinteNodo != null) {
            actual = actual.siguinteNodo;
        }
        return actual;
    }


    public void EliminarIndicesPares(){
        Nodo actual = primerNodo;
        Nodo anterior = null;
        int posicion = 0;

        while (actual != null) {
            if (posicion % 2 == 0) {
                // La posición es par, eliminamos el nodo
                if (anterior == null) {
                    // Si es el primer nodo, actualizamos nodoPrimero
                    primerNodo = actual.siguinteNodo;
                } else {
                    // Si no es el primer nodo, actualizamos el enlace del nodo anterior
                    anterior.siguinteNodo = actual.siguinteNodo;
                }

                // Disminuimos el tamaño de la lista
                tamano--;
            } else {
                // No es una posición par, avanzamos al siguiente nodo y aumentamos la posición
                anterior = actual;
                actual = actual.siguinteNodo;
            }

            // Avanzamos al siguiente nodo y aumentamos la posición
            posicion++;
        }
    }

    public void imprimir(){
        Nodo actual=primerNodo;
        while (actual!=null){
            System.out.println(actual.valor);
            actual=actual.siguinteNodo;

        }
    }
}
