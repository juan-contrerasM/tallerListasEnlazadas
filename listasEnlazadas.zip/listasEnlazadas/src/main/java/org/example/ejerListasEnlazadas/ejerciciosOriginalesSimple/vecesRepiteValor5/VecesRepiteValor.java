package org.example.ejerListasEnlazadas.ejerciciosOriginalesSimple.vecesRepiteValor5;

public class VecesRepiteValor {
    public static void main(String[] args) {
        ListaSimple<Integer> numeros= new ListaSimple<>();

        numeros.agregarfinal(1);
        numeros.agregarfinal(1);
        numeros.agregarfinal(1);
        numeros.agregarfinal(1);
        numeros.agregarfinal(1);

        int valor= 1;
        int contador=0;


        ListaSimple<Integer> numerosImpares= new ListaSimple<>();
        for (int i = 0; i < numeros.getTamanio(); i++) {
            if(numeros.obtenerValorNodo(i)==valor){
                contador++;
                System.out.println(contador);
            }

        }
    }
}
