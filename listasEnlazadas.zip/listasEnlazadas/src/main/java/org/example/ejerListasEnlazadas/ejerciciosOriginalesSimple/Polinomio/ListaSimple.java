package org.example.ejerListasEnlazadas.ejerciciosOriginalesSimple.Polinomio;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * Definici�n de la clase lista Simple de tipo Generics
 * @param <T>
 *
 * **/

public class ListaSimple<T> {

    private Nodo<T> nodoPrimero;
    private Nodo<T> nodoUltimo;
    private int tamanio;


    public ListaSimple() {
        nodoPrimero = null;
        nodoUltimo = null;
        tamanio = 0;
    }


    //Metodos basicos


    //Agregar al inicio de la lista
    public void agregarInicio(T valorBase, T valorExponente) {
        Nodo<T> nuevoNodo = new Nodo<>(valorBase, valorExponente);
        if(estaVacia())	{
            nodoPrimero = nuevoNodo;
            nodoUltimo = nuevoNodo;
        }
        else{
            nuevoNodo.setSiguienteNodo(nodoPrimero);
            nodoPrimero = nuevoNodo;
        }
        tamanio++;
    }


    //Agregar al final de la lista
    public void agregarfinal(T valorBase, T valorExponente) {
        Nodo<T> nodo = new Nodo<>(valorBase, valorExponente);

        if( estaVacia() ) {
            nodoPrimero = nodoUltimo = nodo;
        }else {
            nodoUltimo.setSiguienteNodo(nodo);
            nodoUltimo = nodo;
        }
        tamanio++;
    }





    //Verificar si indice es valido
    private boolean indiceValido(int indice) {
        if( indice >= 0 && indice < tamanio ) {
            return true;
        }
        throw new IndexOutOfBoundsException("Indice no valido");
    }


    //Verificar si la lista esta vacia
    public boolean estaVacia() {
        return(nodoPrimero == null)?true:false;
    }


    /**
     * Imprime en consola la lista enlazada
     */
    public void imprimirLista() {

        Nodo<T> aux = nodoPrimero;

        while(aux!=null) {
            if(aux.getValorExponente().equals("0")){
                System.out.println(aux.getValorBase()+"x");
            }else {
                System.out.print(aux.getValorBase() + "x^" + aux.getValorExponente() + "\t");
                aux = aux.getSiguienteNodo();
            }
        }

        System.out.println();
    }






    private Nodo<T> obtenerNodo(int indice) {

        if(indice>=0 && indice<tamanio) {

            Nodo<T> nodo = nodoPrimero;

            for (int i = 0; i < indice; i++) {
                nodo = nodo.getSiguienteNodo();
            }

            return nodo;
        }

        return null;
    }





    public int obtenerPosicionNodo(T base, T exponente) {

        int i = 0;

        for( Nodo<T> aux = nodoPrimero ; aux!=null ; aux = aux.getSiguienteNodo() ) {
            if( aux.getValorExponente().equals(base)&& aux.getValorBase().equals(exponente) ) {
                return i;
            }
            i++;
        }

        return -1;
    }




    public class IteradorListaSimple implements Iterator<T>{
        private Nodo<T> nodo;
        private int posicion;
        /**
         * Constructor de la clase Iterador
         * @param
         */
        public IteradorListaSimple(Nodo<T> nodo) {
            this.nodo = nodo;
            this.posicion = 0;
        }
        @Override
        public boolean hasNext() {
            return nodo!=null;
        }
        @Override
        public T next() {
            T valor = nodo.getValorBase();
            nodo = nodo.getSiguienteNodo();// i++;
            posicion++;
            return valor;
        }
        /**
         * Posici�n actual de la lista
         * @return posici�n
         */
        public int getPosicion() {
            return posicion;
        }

    }


    //Metodos get y set de la clase ListaSimple


    public Nodo<T> getNodoPrimero() {
        return nodoPrimero;
    }


    public void setNodoPrimero(Nodo<T> nodoPrimero) {
        this.nodoPrimero = nodoPrimero;
    }


    public int getTamanio() {
        return tamanio;
    }


    public void setTamanio(int tamanio) {
        this.tamanio = tamanio;
    }







}
