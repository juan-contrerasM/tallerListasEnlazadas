package org.example.ejerListasEnlazadas.ejercicioPrueba.obtenerCedulasPares2;

public class Nodo {
     Nodo siguienteNodo;
  Persona valor;

    public  Nodo(Persona persona){
        siguienteNodo=null;
        this.valor=persona;
    }
}
