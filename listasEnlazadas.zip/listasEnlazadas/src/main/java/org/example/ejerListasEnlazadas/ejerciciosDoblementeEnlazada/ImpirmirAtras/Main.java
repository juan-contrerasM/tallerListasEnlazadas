package org.example.ejerListasEnlazadas.ejerciciosDoblementeEnlazada.ImpirmirAtras;

public class Main {
    public static void main(String[] args) {
        ListaDoble<Integer>numeros= new ListaDoble<>();

        numeros.agregarInicio(1);
        numeros.agregarInicio(2);
        numeros.agregarInicio(3);
        numeros.agregarInicio(4);
        numeros.agregarInicio(5);
        numeros.agregarInicio(1);

        numeros.imprimirLista();
    }
}
