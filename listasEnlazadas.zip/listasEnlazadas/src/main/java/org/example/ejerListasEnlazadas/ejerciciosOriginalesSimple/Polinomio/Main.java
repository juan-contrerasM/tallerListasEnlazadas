package org.example.ejerListasEnlazadas.ejerciciosOriginalesSimple.Polinomio;

import java.util.ListResourceBundle;

public class Main {

    public static void main(String[] args) {


        ListaSimple<Integer>list= new ListaSimple<>();

        list.agregarfinal(2,4);
        list.agregarfinal(2,2);
        list.agregarfinal(1,0);


        list.imprimirLista();


    }

    public void tabla(ListaSimple<Integer>){


    }



}
