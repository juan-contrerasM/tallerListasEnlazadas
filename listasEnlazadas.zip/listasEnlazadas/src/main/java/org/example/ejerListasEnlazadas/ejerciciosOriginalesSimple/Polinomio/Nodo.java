package org.example.ejerListasEnlazadas.ejerciciosOriginalesSimple.Polinomio;


/**
 * Clase nodo aplicando Generics

 * **/


public class Nodo<T> {

	private Nodo<T> siguienteNodo;
	private T valorBase;

	private T valorExponente;


	/**
	 * Constructor de la clase Nodo
	 *
	 * @paramo Elemento que se guarda en el Nodo
	 */
	public Nodo(T valorBase, T valorExponente) {
		this.valorBase = valorBase;
		this.valorExponente=valorExponente;
	}


	/**
	 * Constructor de la clase Nodo
	 */
	public Nodo(T base, T exponente, Nodo<T> siguiente) {
		super();
		this.valorBase = base;
		this.valorExponente = exponente;
		this.siguienteNodo = siguiente;
	}


	//Metodos get y set de la clase Nodo

	public Nodo<T> getSiguienteNodo() {
		return siguienteNodo;
	}


	public void setSiguienteNodo(Nodo<T> siguienteNodo) {
		this.siguienteNodo = siguienteNodo;
	}


	public T getValorBase() {
		return valorBase;
	}


	public void setValorBase(T valorBase) {
		this.valorBase = valorBase;
	}

	public T getValorExponente() {
		return valorExponente;
	}

	public void setValorExponente(T valorExponente) {
		this.valorExponente = valorExponente;
	}
}
