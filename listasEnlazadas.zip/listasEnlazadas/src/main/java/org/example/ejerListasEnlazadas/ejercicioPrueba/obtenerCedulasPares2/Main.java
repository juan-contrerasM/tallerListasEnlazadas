package org.example.ejerListasEnlazadas.ejercicioPrueba.obtenerCedulasPares2;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        ListaSimple lista = new ListaSimple();
        Persona p1 = new Persona("1", "Juan");
        Persona p2 = new Persona("12", "Jose");
        Persona p3 = new Persona("133", "contreras");
        Persona p4 = new Persona("1444", "molina");
        lista.agregarNodo(p1);
        lista.agregarNodo(p2);
        lista.agregarNodo(p3);
        lista.agregarNodo(p4);

        List<Persona> lisPerons = lista.obtenerCedulasPares();
        for (Persona p : lisPerons) {
            System.out.println(p.nombre + " " + p.cedula + "\n");
        }


    }
}
