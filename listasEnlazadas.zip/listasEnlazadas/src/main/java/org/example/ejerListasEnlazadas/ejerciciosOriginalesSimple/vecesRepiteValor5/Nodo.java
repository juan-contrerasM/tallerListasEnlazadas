package org.example.ejerListasEnlazadas.ejerciciosOriginalesSimple.vecesRepiteValor5;


/**
 * Clase nodo aplicando Generics

 * **/


public class Nodo {

	private Nodo siguienteNodo;
	private int valorNodo;
	
	
	/**
	 * Constructor de la clase Nodo
	 * @paramo Elemento que se guarda en el Nodo
	 */
	public Nodo(int valorNodo) {
		this.valorNodo = valorNodo;
	}
	
	
	/**
	 * Constructor de la clase Nodo
	 * @param dato Elemento que se guarda en el Nodo
	 * @param siguiente Enlace al siguiente Nodo
	 */
	public Nodo(int dato, Nodo siguiente) {
		super();
		this.valorNodo = dato;
		this.siguienteNodo = siguiente;
	}
	

	//Metodos get y set de la clase Nodo
	
	public Nodo getSiguienteNodo() {
		return siguienteNodo;
	}


	public void setSiguienteNodo(Nodo siguienteNodo) {
		this.siguienteNodo = siguienteNodo;
	}


	public int getValorNodo() {
		return valorNodo;
	}


	public void setValorNodo(int valorNodo) {
		this.valorNodo = valorNodo;
	}
}
