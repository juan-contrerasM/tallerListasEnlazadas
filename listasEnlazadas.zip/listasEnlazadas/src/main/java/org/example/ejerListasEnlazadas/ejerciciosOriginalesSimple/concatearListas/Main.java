package org.example.ejerListasEnlazadas.ejerciciosOriginalesSimple.concatearListas;

public class Main {
    public static void main(String[] args) {
        ListaSimple<Integer>list1=new ListaSimple<>();
        list1.agregarfinal(1);
        list1.agregarfinal(1);
        list1.agregarfinal(1);
        list1.agregarfinal(1);

        ListaSimple<Integer>list2=new ListaSimple<>();
        list2.agregarfinal(2);
        list2.agregarfinal(2);
        list2.agregarfinal(2);
        list2.agregarfinal(2);

        ListaSimple<Integer>lista=list1.concatenarListas(list1,list2);
        lista.imprimirLista();
    }
}
