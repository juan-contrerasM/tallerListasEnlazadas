package org.example.ejerListasEnlazadas.ejerciciosDoblementeEnlazada.cedulasPares;

public class Persona {
    String cedula;
    String nombre;

    public Persona(String cedula, String nombre){
        this.cedula=cedula;
        this.nombre=nombre;

    }
}
