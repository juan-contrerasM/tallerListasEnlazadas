package org.example.ejerListasEnlazadas.ejerciciosOriginalesSimple.eliminarNumparasListas3;

public class EliminarNumParesListas {
    public static void main(String[] args) {
        ListaSimple<Integer> numeros= new ListaSimple<>();

        numeros.agregarfinal(1);
        numeros.agregarfinal(2);
        numeros.agregarfinal(3);
        numeros.agregarfinal(4);
        numeros.agregarfinal(5);

        for (int i = 0; i < numeros.getTamanio(); i++) {
            if(numeros.obtenerValorNodo(i)%2==0){
                System.out.println(numeros.eliminar(numeros.obtenerValorNodo(i)));
            }

        }
    }
}
