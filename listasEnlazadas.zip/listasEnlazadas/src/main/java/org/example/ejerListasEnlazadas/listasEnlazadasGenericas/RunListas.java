package org.example.ejerListasEnlazadas.listasEnlazadasGenericas;

import java.util.ArrayList;
import java.util.Iterator;



public class RunListas {

	public static void main(String[] args) {


		ListaSimple<Integer> lista = new ListaSimple<>();
		lista.agregarfinal(1);
		lista.agregarfinal(2);
		lista.agregarfinal(3);
		lista.agregarfinal(4);
		
		recorrerRecursivo(lista,0);
		
		
		
		
		
		
		
		
		ArrayList lista1 = new ArrayList();	
		ListaSimple<Integer> listaEnteros = new ListaSimple<>();
		listaEnteros.agregarInicio(1);
		listaEnteros.agregarInicio(2);
		listaEnteros.agregarInicio(3);
		listaEnteros.agregarInicio(4);
		listaEnteros.agregarInicio(5);
		listaEnteros.agregarInicio(6);
//		
//		
//		borrarPosicionesParesOImpares(listaEnteros);
//		
//		listaEnteros.imprimirLista();
		
		
		
	}
	
	private static void recorrerRecursivo(ListaSimple<Integer> lista, int i) {
		
		if(i > lista.getTamanio()) {
			System.out.println("Termino");
		}else {
			System.out.println(lista.obtenerValorNodo(i));
			recorrerRecursivo(lista, i+1);
		}
		
	}

	static <T> boolean borrarParesOImpares (Nodo<T> nodo) {
		boolean resul;
		Nodo<T> aux;
		if (nodo != null) {
			aux = nodo;
			nodo = nodo.getSiguienteNodo();
			resul = borrarParesOImpares (nodo);
			if (!resul && (nodo != null))
			{
				aux.setSiguienteNodo(nodo.getSiguienteNodo());
				resul = !resul;
			}

		}
		else resul = true;
		return resul;
	}
	
	static <T> void borrarPosicionesParesOImpares (ListaSimple<T> lista){
		boolean resul = borrarParesOImpares (lista.getNodoPrimero());
		if (!resul)
			lista.setNodoPrimero(lista.getNodoPrimero().getSiguienteNodo());
	}
	
	
	

}
