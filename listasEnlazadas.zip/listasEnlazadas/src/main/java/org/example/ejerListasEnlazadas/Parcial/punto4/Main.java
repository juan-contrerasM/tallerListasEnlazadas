package org.example.ejerListasEnlazadas.Parcial.punto4;

import org.example.ejerListasEnlazadas.ejerciciosOriginalesSimple.concatearListas.ListaSimple;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ListaDoble<Integer> numeros=new ListaDoble<>();
        numeros.agregarfinal(1);
        numeros.agregarfinal(2);
        numeros.agregarfinal(3);
        numeros.agregarfinal(4);

       ArrayList<Integer>list= numeros.imprimirImpares();

        for (int i = 0; i < list.size(); i++) {
            System.out.println( list.get(i));

        }
    }
}
