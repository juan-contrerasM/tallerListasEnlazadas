package org.example.ejerListasEnlazadas.ejercicioPrueba.eliminarNumeroPares3;




public class Main {
    public static void main(String[] args) {
        ListaSimple listaSimple=new ListaSimple();
        listaSimple.agregarNodo(1);
        listaSimple.agregarNodo(2);
        listaSimple.agregarNodo(3); //
        listaSimple.agregarNodo(4);
        listaSimple.agregarNodo(5); //

        listaSimple.imprimir();
        System.out.println("------------");
        listaSimple.EliminarIndicesPares();
        listaSimple.imprimir();

    }


}
