package org.example.ejerListasEnlazadas.ejercicioPrueba.obtenerNumerosImpares1;


public class Nodo {

   Nodo siguienteNodo;
  int valorNodo;

    // Constructor de la clase Nodo
    public Nodo(int valorNodo) {
        siguienteNodo = null;
        this.valorNodo = valorNodo;
    }
}